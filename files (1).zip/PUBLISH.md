# How to publish Tok Salone (nothing of Claude in it)

Your folder is a complete, installable app. It has no Claude name, no Claude sign-in and nothing from Claude inside.

## Step A. Finish Firebase (free)
Link: https://console.firebase.google.com
1. Firestore Database > Create database > production mode.
2. Firestore > Rules tab > paste the rules from SETUP.md > Publish.
3. Project settings (gear) > Your apps > Web `</>` > register > copy apiKey, authDomain, projectId, appId.
4. Open index.html in a text editor, replace each PASTE_HERE with those values, save.

## Step B. Put the website online (free)
Link: https://app.netlify.com/drop
Drag the whole `jesnap` folder onto the page. You get a link like https://something.netlify.app. That link is your public app. Anyone can open it, sign up and chat.
Then in Firebase > Authentication > Settings > Authorized domains > Add domain, add your Netlify address.

People can already install it: on a phone, open the link in the browser and choose "Add to Home screen". It shows up as an app with your mountain logo.

## Step C. Your own web address (about 10 to 15 dollars a year)
Link: https://www.namecheap.com (or https://domains.cloudflare.com)
Buy a name such as toksalone.com, then in Netlify: Domain settings > Add a domain.

## Step D. Google Play Store (Android)
1. Make a developer account, one-time fee about 25 dollars: https://play.google.com/console/signup
2. Go to https://www.pwabuilder.com and paste your Netlify (or own) link. It checks your app and builds an Android package for Play Store.
3. Download the Android package, then in Play Console > Create app > upload it.
4. Fill in the store page: description, screenshots, and a Privacy Policy web address. Submit for review.
(New personal Play accounts must usually test with about 12 people for 14 days before the app can go public.)

## Step E. Apple App Store (iPhone)
1. Apple Developer Program, about 99 dollars a year: https://developer.apple.com/programs/enroll/
2. You need a Mac to build the iPhone version. PWABuilder can make an iOS project to open in Xcode.
3. Upload through App Store Connect: https://appstoreconnect.apple.com
Apple is stricter. Chat apps must have a way to report and block users and a Privacy Policy.

## Other places
- Huawei AppGallery: https://developer.huawei.com/consumer/en/appgallery/
- Samsung Galaxy Store: https://seller.samsungapps.com
- Amazon Appstore: https://developer.amazon.com/apps-and-games

## Before you launch
- Search for the name Tok Salone in the app stores to make sure it is free.
- Write a Privacy Policy and Terms page (ask me and I will write them).
- Add report and block buttons (ask me and I will add them). Stores require this for chat apps.
- Chats are not end-to-end encrypted. Say so in your Privacy Policy.
